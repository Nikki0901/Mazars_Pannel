export const AGORA_APP_ID = '08c1f31d26704cdbb502b8d76dedfa07' // set your app id here


// de3b3dfacbd44aa8b0b59527213cb39c
// 8c02d085430140d69e0517695c7b6777