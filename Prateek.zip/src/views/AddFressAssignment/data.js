
export const purpose = [
    { value: "Assessment", label: "Assessment" },
    { value: "Appeal", label: "Appeal" },
    { value: "Filing before any Court", label: "Filing before any Court" },
    {
        value: "Filing before any Authority",
        label: "Filing before any Authority",
    },
    { value: "Others", label: "Others" },
];




// export const assessment_year = [
//     {
//         value: "2022-23",
//         label: "2022-23",
//     },
//     {
//         value: "2021-22",
//         label: "2021-22",
//     },
//     {
//         value: "2020-21",
//         label: "2020-21",
//     },
//     {
//         value: "2019-20",
//         label: "2019-20",
//     },
//     {
//         value: "2018-19",
//         label: "2018-19",
//     },
//     {
//         value: "2017-18",
//         label: "2017-18",
//     },
//     {
//         value: "2016-17",
//         label: "2016-17",
//     },
//     {
//         value: "2015-16",
//         label: "2015-16",
//     },
//     {
//         value: "2014-15",
//         label: "2014-15",
//     },
//     {
//         value: "2013-14",
//         label: "2013-14",
//     },
//     {
//         value: "2012-13",
//         label: "2012-13",
//     },
//     {
//         value: "2011-12",
//         label: "2011-12",
//     }, 
//     {
//         value: "2010-11",
//         label: "2010-11",
//     },
//     {
//         value: "2009-10",
//         label: "2009-10",
//     },
//     {
//         value: "2008-09",
//         label: "2008-09",
//     },
//     {
//         value: "2007-08",
//         label: "2007-08",
//     },
//     {
//         value: "2006-07",
//         label: "2006-07",
//     },
//     {
//         value: "2005-06",
//         label: "2005-06",
//     },
//     {
//         value: "2004-05",
//         label: "2004-05",
//     },
//     {
//         value: "2003-04",
//         label: "2003-04",
//     },
//     {
//         value: "2002-03",
//         label: "2002-03",
//     },
//     {
//         value: "2001-02",
//         label: "2001-02",
//     },
//     {
//         value: "2000-01",
//         label: "2000-01",
//     },
// ];