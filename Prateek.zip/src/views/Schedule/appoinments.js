export const resourcesData = [
  {
    text: "Room 101",
    id: 1,
  },
  {
    text: "Room 102",
    id: 2,
  },
  {
    text: "Room 103",
    id: 3,
  },
  {
    text: "Meeting room",
    id: 4,
  },
  {
    text: "Conference hall",
    id: 5,
  },
  {
    text: "abc",
    id: 71,
  },
  {
    text: "jkjk",
    id: 72,
  }
];


// export const owners = [{
//   text: 'Samantha Bright',
//   id: 1,
//   color: '#727bd2'
// }, {
//   text: 'John Heart',
//   id: 2,
//   color: '#32c9ed'
// }, {
//   text: 'Todd Hoffman',
//   id: 3,
//   color: '#2a7ee4'
// }, {
//   text: 'Sandra Johnson',
//   id: 4,
//   color: '#7b49d3'
// }];