
// http://13.232.121.233/mazarsapi/v1/




//for local
export const baseUrl = "http://13.232.121.233/mazarsapi/v1";
export const ImageUrl = "http://13.232.121.233/mazarsapi/assets/image";
export const ReportUrl = "http://13.232.121.233/mazarsapi/assets/upload/report";




// //for server
// export const baseUrl = "https://mazarsapi.multitvsolution.com/mazarapi/v1";
// export const ImageUrl = "https://mazarsapi.multitvsolution.com/mazarapi/assets/image";
// export const ReportUrl = "https://mazarsapi.multitvsolution.com/mazarapi/assets/upload/report";

// for local
export const baseUrl2 = "http://13.232.121.233";

// for server 
// export const baseUrl2 = "https://mazarsapi.multitvsolution.com"








