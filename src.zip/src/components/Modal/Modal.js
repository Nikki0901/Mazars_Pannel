import React, {useState} from "react";
import { NavLink ,Link } from "react-router-dom";
// import  "./index.css";




// const ModalQuery = () => {



//   return(
//     <>
     
//     </>
//   )
// }


// function Modal() {
//   return (
//     <>
//       <div
//         class="modal fade"
//         id="exampleModal"
//         tabindex="-1"
//         aria-labelledby="exampleModalLabel"
//         aria-hidden="true"
//       >
//         <div class="modal-dialog">
//           <div class="modal-content">
//             <div class="modal-header">
//               <img
//                 src="./../assets/images/mazars-logo.png"
//                 style={{ height: "auto", width: "25%" }}
//                 alt=""
//               />
//               <button
//                 type="button"
//                 class="close"
//                 data-dismiss="modal"
//                 aria-label="Close"
//               >
//                 <span aria-hidden="true">close</span>
//               </button>
//             </div>
//             <div class="modal-body">
//               <h4>Would you like to post a Query?</h4>
//             </div>
          
//             <div class="modal-footer m-auto">
//               <Link to="/register-yourself" class="btn btn-primary">
//                 Yes
//               </Link>
//               <Link to="/signin" class="btn btn-primary">
//                No
//               </Link>
//             </div>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// }

export default ModalQuery;
