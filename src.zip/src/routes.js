

import Extra from "./components/Extra/Extra";

var routes = [
    {
      path: "/extra",
      name: "Extra",
      component: Extra,
      layout: "/layout",
    },

  ];
  
  export default routes;